<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'Paste your Twitter Consumer Key Here');
    define('CONSUMER_SECRET', 'Paste your Twitter Consumer Secret Here');

    // User Access Token
    define('ACCESS_TOKEN', 'Paste your Twitter App Access Token Here');
    define('ACCESS_SECRET', 'Paste your Twitter App Access Secret Here');